echo "Enter num1:"
read n1
echo "Enter num2:"
read n2
temp=$n1
n1=$n2
n2=$temp
echo "num1: $n1 ,num2: $n2"
